#!/usr/bin/env python3
"""Measure runnable waiting time and CPU migrations using scheduler tracepoints."""

import argparse
import ctypes as ct
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def positive_int(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return number


def seconds(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError("must be a positive, finite duration")
    return number


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("-p", "--pid", type=positive_int,
                    help="process PID: existing threads and future descendants")
parser.add_argument("-d", "--duration", type=seconds,
                    help="stop after this many seconds (default: until Ctrl-C)")
parser.add_argument("-i", "--interval", type=seconds, default=1.0,
                    help="cumulative reporting interval in seconds (default: 1)")
parser.add_argument("--ebpf", action="store_true",
                    help="print the BPF source without requiring BCC or root")
parser.add_argument("command", nargs=argparse.REMAINDER,
                    help="application and arguments to launch, preceded by --")


BPF_TEXT = r"""
#include <uapi/linux/ptrace.h>
#include <linux/sched.h>

enum reason { WAKEUP = 0, RUNNABLE_SWITCH = 1 };
enum counter { MIGRATIONS = 0 };

struct waiting_t {
    u64 since_ns;
    u32 reason;
};

struct summary_t {
    u64 samples;
    u64 total_ns;
};

// Task maps use thread IDs and are shared across CPUs to follow migrations.
// Selected threads and descendants. As BPF maps are key-value, a small placeholder (u8) is provided. Simply put "1" in
// the value.
BPF_HASH(targets, u32, u8, 65536);

// Unfinished runnable interval per thread: start timestamp and cause.
BPF_HASH(waiting, u32, struct waiting_t, 65536);

// Last observed execution CPU per thread, retained while the thread sleeps.
BPF_HASH(last_cpu, u32, u32, 65536);

// Per-CPU counts and latency sums
// We have 4 elements (bucket) in the array:
// Bucket 0: wakeup,              same CPU
// Bucket 1: wakeup,              different CPU
// Bucket 2: runnable switch-out, same CPU
// Bucket 3: runnable switch-out, different CPU
// Therefore to select the appropriate bucket, you can use the formula:
// bucket = reason * 2 + changed_cpu
BPF_PERCPU_ARRAY(summaries, struct summary_t, 4);

// Per-CPU migration totals at index MIGRATIONS, summed for reporting.
BPF_PERCPU_ARRAY(counters, u64, 1);

static inline int is_target(u32 tid)
{
    return tid != 0 && (TARGET_PID == 0 || targets.lookup(&tid) != 0);
}

static inline int on_wakeup(u32 tid)
{
    if (!is_target(tid))
        return 0;

    // TODO: record the runnable timestamp and WAKEUP cause.
    // A wakeup CPU is a destination, not the last execution CPU.
    return 0;
}

// A sleeping thread becomes runnable, but may still wait for CPU time.
TRACEPOINT_PROBE(sched, sched_wakeup)
{
    return on_wakeup(args->pid);
}

// A newly created thread becomes runnable for the first time.
TRACEPOINT_PROBE(sched, sched_wakeup_new)
{
    return on_wakeup(args->pid);
}

// A CPU switches from prev to next, ending next's wait and possibly starting prev's.
TRACEPOINT_PROBE(sched, sched_switch)
{
    u32 prev_tid = args->prev_pid;
    u32 next_tid = args->next_pid;

    if (is_target(prev_tid)) {
        // TODO: save the execution CPU and start a wait if prev remains runnable.
        // Otherwise clear stale waits. prev_state's reporting bit marks preemption.
    }

    if (is_target(next_tid)) {
        // TODO: aggregate a known wait by cause and execution CPU change, then consume it.
        // Without CPU history, skip classification.
        // Always remember the incoming thread's current CPU for later intervals.
    }
    return 0;
}

// The scheduler changes a thread's CPU assignment; execution may happen later.
TRACEPOINT_PROBE(sched, sched_migrate_task)
{
    if (!is_target(args->pid))
        return 0;

    // TODO: increment counters[MIGRATIONS].
    // Migration is not execution: leave last_cpu and the waiting start alone.
    return 0;
}

// Register launched children before they run, and follow selected tasks' descendants.
TRACEPOINT_PROBE(sched, sched_process_fork)
{
    u32 parent = args->parent_pid;
    u32 child = args->child_pid;
    if (TARGET_PID != 0 && (is_target(parent) ||
            (LAUNCHER_PID != 0 && parent == LAUNCHER_PID))) {
        u8 yes = 1;
        targets.update(&child, &yes);
    }
    return 0;
}

// The kernel releases a task; discard its tracking state.
TRACEPOINT_PROBE(sched, sched_process_free)
{
    u32 tid = args->pid;
    waiting.delete(&tid);
    last_cpu.delete(&tid);
    targets.delete(&tid);
    return 0;
}
"""


def report(bpf, elapsed, file=None):
    file = sys.stdout if file is None else file
    print(f"\nCumulative after {elapsed:.2f}s", file=file)
    print(f"{'Cause':<18} {'Resumed on':<14} {'Samples':>12} {'Mean (us)':>14}", file=file)
    table = bpf["summaries"]
    for reason, label in enumerate(("wakeup", "runnable switch")):
        for changed, cpu_label in enumerate(("same CPU", "different CPU")):
            leaves = table[ct.c_int(reason * 2 + changed)]
            count = sum(leaf.samples for leaf in leaves)
            total_ns = sum(leaf.total_ns for leaf in leaves)
            mean = f"{total_ns / count / 1000:.3f}" if count else "n/a"
            print(f"{label:<18} {cpu_label:<14} {count:>12} {mean:>14}", file=file)
    counters = bpf["counters"]
    migrations = sum(counters[ct.c_int(0)])
    print(f"Scheduler migrations: {migrations}", file=file, flush=True)


def main():
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if args.command and not command:
        parser.error("expected an application after --")
    if args.pid and command:
        parser.error("use either --pid or an application command")
    source = BPF_TEXT.replace("TARGET_PID", str(args.pid or int(bool(command))))
    source = source.replace("LAUNCHER_PID", str(os.getpid() if command else 0))
    if args.ebpf:
        print(source)
        return 0
    if os.geteuid() != 0:
        parser.exit(1, "Run with sudo on the Linux host to attach scheduler tracepoints.\n")
    try:
        from bcc import BPF
    except ImportError:
        parser.exit(1, "BCC is missing. Install python3-bpfcc and matching kernel headers.\n")

    tids = []
    if args.pid:
        try:
            tids = [int(path.name) for path in Path(f"/proc/{args.pid}/task").iterdir()]
        except OSError as error:
            parser.exit(1, f"Cannot inspect process {args.pid}: {error}\n")
    try:
        bpf = BPF(text=source)
    except Exception as error:
        parser.exit(1, f"Cannot load BPF program: {error}\n")

    stopped = False
    process = None
    output = sys.stderr if command else sys.stdout

    def stop(_signum, _frame):
        nonlocal stopped
        stopped = True

    old_handlers = {sig: signal.signal(sig, stop) for sig in (signal.SIGINT, signal.SIGTERM)}
    try:
        for tid in tids:
            bpf["targets"][ct.c_uint(tid)] = ct.c_ubyte(1)
        start = time.monotonic()
        if command:
            process = subprocess.Popen(command, start_new_session=True)
        pid = process.pid if process is not None else args.pid
        target = f"process {pid} and descendants" if pid else "all tasks"
        print(f"Tracing {target}. Press Ctrl-C to stop.", file=output, flush=True)
        next_report = start + args.interval
        deadline = start + args.duration if args.duration else float("inf")
        while not stopped:
            if process is not None and process.poll() is not None:
                break
            now = time.monotonic()
            if now >= deadline:
                break
            if now >= next_report:
                report(bpf, now - start, file=output)
                next_report = now + args.interval
            time.sleep(min(0.2, max(0, min(next_report, deadline) - now)))
        report(bpf, time.monotonic() - start, file=output)
    except OSError as error:
        parser.exit(1, f"Cannot launch application: {error}\n")
    finally:
        if process is not None:
            for signum in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(process.pid, signum)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    continue
            process.wait()
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
        bpf.cleanup()
    if process is None:
        return 0
    return process.returncode if process.returncode >= 0 else 128 - process.returncode


if __name__ == "__main__":
    sys.exit(main())
