#define _GNU_SOURCE
#include <errno.h>
#include <getopt.h>
#include <inttypes.h>
#include <limits.h>
#include <linux/futex.h>
#include <math.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

enum workload { CPU, MEMORY, SYNC };
struct node {
    struct node *next;
    unsigned char padding[64 - sizeof(struct node *)];
};
_Static_assert(sizeof(struct node) == 64, "nodes should occupy one 64-byte cache line");
_Static_assert(sizeof(_Atomic int) == 4, "Linux futex words must be 32 bits");

struct config {
    enum workload workload;
    double duration;
    unsigned threads;
    size_t memory_mb;
    cpu_set_t cpus;
    bool json;
};

struct run {
    const struct config *config;
    pthread_mutex_t lock;
    pthread_cond_t condition;
    unsigned ready;
    bool start;
    atomic_bool stop;
    atomic_int error;
    _Alignas(64) _Atomic int turn;
};

struct worker {
    struct run *run;
    unsigned id;
    uint64_t operations;
    uint64_t checksum;
};

static volatile sig_atomic_t interrupted;

static void handle_signal(int signum)
{
    (void)signum;
    interrupted = 1;
}

static uint64_t monotonic_ns(void)
{
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) {
        perror("clock_gettime");
        exit(EXIT_FAILURE);
    }
    return (uint64_t)now.tv_sec * UINT64_C(1000000000) + (uint64_t)now.tv_nsec;
}

static uint64_t random_step(uint64_t *state)
{
    uint64_t x = *state;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    *state = x;
    return x * UINT64_C(2685821657736338717);
}

static void usage(FILE *stream, const char *program)
{
    fprintf(stream,
            "Usage: %s --workload cpu|memory|sync [options]\n"
            "  -w, --workload NAME   Workload (default: cpu)\n"
            "  -d, --duration SEC    Measurement duration, 0 < SEC <= 86400 (default: 5)\n"
            "  -t, --threads N       Workers (default: 1, or 2 for sync)\n"
            "  -c, --cpus LIST       Shared allowed CPU set, e.g. 0,2-3\n"
            "  -m, --memory-mb N     MiB per memory worker (default: 64)\n"
            "  -j, --json            Print a JSON result\n"
            "  -h, --help            Show help\n"
            "Sync requires exactly two threads. CPU IDs must be allowed by the\n"
            "parent's affinity. Workers may migrate within the selected set.\n",
            program);
}

static unsigned long parse_integer(const char *text, const char *name,
                                   unsigned long maximum)
{
    char *end;
    errno = 0;
    unsigned long value = strtoul(text, &end, 10);
    if (*text < '0' || *text > '9' || errno || *end || !value || value > maximum) {
        fprintf(stderr, "Invalid %s: %s\n", name, text);
        exit(EXIT_FAILURE);
    }
    return value;
}

static void parse_cpus(const char *text, const cpu_set_t *allowed, cpu_set_t *set)
{
    const char *cursor = text;
    CPU_ZERO(set);
    while (*cursor) {
        char *end;
        if (*cursor < '0' || *cursor > '9')
            goto invalid;
        errno = 0;
        unsigned long first = strtoul(cursor, &end, 10);
        if (errno || first >= CPU_SETSIZE)
            goto invalid;
        unsigned long last = first;
        cursor = end;
        if (*cursor == '-') {
            cursor++;
            if (*cursor < '0' || *cursor > '9')
                goto invalid;
            errno = 0;
            last = strtoul(cursor, &end, 10);
            if (errno || last >= CPU_SETSIZE || last < first)
                goto invalid;
            cursor = end;
        }
        for (unsigned long cpu = first; cpu <= last; cpu++) {
            if (!CPU_ISSET((int)cpu, allowed)) {
                fprintf(stderr, "CPU %lu is outside the inherited affinity\n", cpu);
                exit(EXIT_FAILURE);
            }
            CPU_SET((int)cpu, set);
        }
        if (!*cursor)
            break;
        if (*cursor++ != ',' || !*cursor)
            goto invalid;
    }
    if (CPU_COUNT(set))
        return;
invalid:
    fprintf(stderr, "Invalid CPU list: %s\n", text);
    exit(EXIT_FAILURE);
}

static struct config parse_options(int argc, char **argv)
{
    struct config config = {.workload = CPU, .duration = 5, .memory_mb = 64};
    cpu_set_t allowed;
    if (sched_getaffinity(0, sizeof(allowed), &allowed) != 0) {
        perror("sched_getaffinity");
        exit(EXIT_FAILURE);
    }
    config.cpus = allowed;
    static const struct option options[] = {
        {"workload", required_argument, NULL, 'w'},
        {"duration", required_argument, NULL, 'd'},
        {"threads", required_argument, NULL, 't'},
        {"cpus", required_argument, NULL, 'c'},
        {"memory-mb", required_argument, NULL, 'm'},
        {"json", no_argument, NULL, 'j'},
        {"help", no_argument, NULL, 'h'},
        {NULL, 0, NULL, 0}
    };
    int option;
    while ((option = getopt_long(argc, argv, "w:d:t:c:m:jh", options, NULL)) != -1) {
        switch (option) {
        case 'w':
            if (!strcmp(optarg, "cpu")) config.workload = CPU;
            else if (!strcmp(optarg, "memory")) config.workload = MEMORY;
            else if (!strcmp(optarg, "sync")) config.workload = SYNC;
            else {
                fprintf(stderr, "Unknown workload: %s\n", optarg);
                exit(EXIT_FAILURE);
            }
            break;
        case 'd': {
            char *end;
            errno = 0;
            config.duration = strtod(optarg, &end);
            if (errno || end == optarg || *end || !isfinite(config.duration) ||
                config.duration <= 0 || config.duration > 86400) {
                fprintf(stderr, "Invalid duration: %s\n", optarg);
                exit(EXIT_FAILURE);
            }
            break;
        }
        case 't': config.threads = (unsigned)parse_integer(optarg, "threads", 4096); break;
        case 'm': config.memory_mb = parse_integer(optarg, "memory size", SIZE_MAX / (1024 * 1024)); break;
        case 'c': parse_cpus(optarg, &allowed, &config.cpus); break;
        case 'j': config.json = true; break;
        case 'h': usage(stdout, argv[0]); exit(EXIT_SUCCESS);
        default: usage(stderr, argv[0]); exit(EXIT_FAILURE);
        }
    }
    if (optind != argc) {
        fprintf(stderr, "Unexpected argument: %s\n", argv[optind]);
        exit(EXIT_FAILURE);
    }
    if (!config.threads)
        config.threads = config.workload == SYNC ? 2 : 1;
    if (config.workload == SYNC && config.threads != 2) {
        fprintf(stderr, "The sync workload requires exactly two threads\n");
        exit(EXIT_FAILURE);
    }
    return config;
}

static struct node *make_cycle(size_t bytes, unsigned id)
{
    size_t count = bytes / sizeof(struct node);
    struct node *nodes = NULL;
    int error = posix_memalign((void **)&nodes, 64, bytes);
    size_t *order = malloc(count * sizeof(*order));
    if (error || !order) {
        free(nodes);
        free(order);
        return NULL;
    }
    memset(nodes, 0, bytes);
    for (size_t i = 0; i < count; i++)
        order[i] = i;
    uint64_t state = UINT64_C(0x9e3779b97f4a7c15) + id;
    for (size_t i = count - 1; i > 0; i--) {
        size_t j = random_step(&state) % (i + 1);
        size_t temporary = order[i];
        order[i] = order[j];
        order[j] = temporary;
    }
    // One shuffled cycle visits the entire allocation before repeating.
    for (size_t i = 0; i < count; i++)
        nodes[order[i]].next = &nodes[order[(i + 1) % count]];
    free(order);
    return nodes;
}

static void cpu_work(struct worker *worker)
{
    uint64_t state = UINT64_C(0x123456789abcdef) + worker->id;
    uint64_t count = 0;
    while (!atomic_load_explicit(&worker->run->stop, memory_order_relaxed)) {
        for (unsigned i = 0; i < 4096; i++)
            state = random_step(&state);
        count += 4096;
    }
    worker->operations = count;
    worker->checksum = state;
}

static void memory_work(struct worker *worker, struct node *nodes)
{
    struct node *cursor = nodes;
    uint64_t count = 0;
    while (!atomic_load_explicit(&worker->run->stop, memory_order_relaxed)) {
        for (unsigned i = 0; i < 256; i++)
            cursor = cursor->next;
        count += 256;
    }
    worker->operations = count;
    worker->checksum = (uint64_t)(cursor - nodes);
}

static int futex_wake(_Atomic int *word, int count)
{
    return (int)syscall(SYS_futex, word, FUTEX_WAKE_PRIVATE, count, NULL, NULL, 0);
}

static void sync_work(struct worker *worker)
{
    struct run *run = worker->run;
    int own_turn = (int)worker->id;
    uint64_t count = 0;
    for (;;) {
        int turn = atomic_load_explicit(&run->turn, memory_order_acquire);
        if (turn == 2)
            break;
        if (turn != own_turn) {
            long result = syscall(SYS_futex, &run->turn, FUTEX_WAIT_PRIVATE,
                                  turn, NULL, NULL, 0);
            if (result == -1 && errno != EINTR && errno != EAGAIN) {
                atomic_store(&run->error, errno);
                atomic_store_explicit(&run->turn, 2, memory_order_release);
                futex_wake(&run->turn, INT_MAX);
                break;
            }
            continue;
        }
        // CAS preserves the terminal value even if shutdown races a handoff.
        if (atomic_compare_exchange_strong_explicit(&run->turn, &turn, 1 - own_turn,
                                                     memory_order_acq_rel,
                                                     memory_order_acquire)) {
            count++;
            futex_wake(&run->turn, 1);
        }
    }
    worker->operations = count;
    worker->checksum = count;
}

static void *worker_main(void *argument)
{
    struct worker *worker = argument;
    struct run *run = worker->run;
    const struct config *config = run->config;
    int error = pthread_setaffinity_np(pthread_self(), sizeof(config->cpus), &config->cpus);
    if (error)
        atomic_store(&run->error, error);
    struct node *nodes = NULL;
    if (!error && config->workload == MEMORY) {
        nodes = make_cycle(config->memory_mb * 1024 * 1024, worker->id);
        if (!nodes)
            atomic_store(&run->error, ENOMEM);
    }
    pthread_mutex_lock(&run->lock);
    run->ready++;
    pthread_cond_broadcast(&run->condition);
    while (!run->start)
        pthread_cond_wait(&run->condition, &run->lock);
    pthread_mutex_unlock(&run->lock);

    if (!atomic_load(&run->stop)) {
        if (config->workload == CPU) cpu_work(worker);
        else if (config->workload == MEMORY) memory_work(worker, nodes);
        else sync_work(worker);
    }
    free(nodes);
    return NULL;
}

static void print_result(const struct config *config, struct worker *workers,
                         double elapsed)
{
    uint64_t operations = 0, checksum = 0;
    for (unsigned i = 0; i < config->threads; i++) {
        operations += workers[i].operations;
        checksum ^= workers[i].checksum;
    }
    uint64_t exchanges = config->workload == SYNC ? workers[1].operations : 0;
    uint64_t units = config->workload == SYNC ? exchanges : operations;
    double rate = (double)units / elapsed;
    double latency = units ? elapsed * 1e9 / (double)units : 0;
    const char *name = config->workload == CPU ? "cpu" : config->workload == MEMORY ? "memory" : "sync";
    const char *unit = config->workload == SYNC ? "exchanges/s" : "operations/s";
    if (config->json) {
        printf("{\"workload\":\"%s\",\"pid\":%ld,\"threads\":%u,\"cpus\":[",
               name, (long)getpid(), config->threads);
        bool first = true;
        for (int cpu = 0; cpu < CPU_SETSIZE; cpu++) {
            if (CPU_ISSET(cpu, &config->cpus)) {
                printf("%s%d", first ? "" : ",", cpu);
                first = false;
            }
        }
        printf("],\"elapsed_s\":%.9f,\"memory_mb_per_thread\":%zu,"
               "\"operations\":%" PRIu64 ",\"exchanges\":%" PRIu64 ","
               "\"rate\":%.3f,\"unit\":\"%s\",\"mean_exchange_ns\":",
               elapsed, config->workload == MEMORY ? config->memory_mb : 0,
               operations, exchanges, rate, unit);
        if (config->workload == SYNC && exchanges) printf("%.3f", latency);
        else printf("null");
        printf(",\"checksum\":%" PRIu64 "}\n", checksum);
    } else {
        printf("workload=%s pid=%ld threads=%u elapsed_s=%.6f cpus=",
               name, (long)getpid(), config->threads, elapsed);
        bool first = true;
        for (int cpu = 0; cpu < CPU_SETSIZE; cpu++) {
            if (CPU_ISSET(cpu, &config->cpus)) {
                printf("%s%d", first ? "" : ",", cpu);
                first = false;
            }
        }
        printf("\noperations=%" PRIu64 " rate=%.3f %s checksum=%" PRIu64 "\n",
               operations, rate, unit, checksum);
        if (config->workload == MEMORY)
            printf("memory_mb_per_thread=%zu\n", config->memory_mb);
        if (config->workload == SYNC) {
            printf("exchanges=%" PRIu64 " mean_exchange_ns=", exchanges);
            if (exchanges) printf("%.3f\n", latency);
            else printf("n/a\n");
        }
    }
}

int main(int argc, char **argv)
{
    struct config config = parse_options(argc, argv);
    if (sched_setaffinity(0, sizeof(config.cpus), &config.cpus) != 0) {
        perror("sched_setaffinity");
        return EXIT_FAILURE;
    }
    struct sigaction action = {.sa_handler = handle_signal};
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, NULL) || sigaction(SIGTERM, &action, NULL)) {
        perror("sigaction");
        return EXIT_FAILURE;
    }
    struct run run = {.config = &config, .lock = PTHREAD_MUTEX_INITIALIZER,
                      .condition = PTHREAD_COND_INITIALIZER};
    atomic_init(&run.stop, false);
    atomic_init(&run.error, 0);
    atomic_init(&run.turn, 0);
    pthread_t *threads = calloc(config.threads, sizeof(*threads));
    struct worker *workers = calloc(config.threads, sizeof(*workers));
    if (!threads || !workers) {
        fprintf(stderr, "Cannot allocate worker state\n");
        free(threads);
        free(workers);
        return EXIT_FAILURE;
    }
    fprintf(stderr, "pid=%ld: preparing %u worker(s); timing starts after setup\n",
            (long)getpid(), config.threads);
    sigset_t termination_signals, previous_mask;
    sigemptyset(&termination_signals);
    sigaddset(&termination_signals, SIGINT);
    sigaddset(&termination_signals, SIGTERM);
    int mask_error = pthread_sigmask(SIG_BLOCK, &termination_signals, &previous_mask);
    if (mask_error) {
        fprintf(stderr, "Cannot block termination signals: %s\n", strerror(mask_error));
        free(workers);
        free(threads);
        return EXIT_FAILURE;
    }
    unsigned created = 0;
    for (; created < config.threads; created++) {
        workers[created] = (struct worker){.run = &run, .id = created};
        int error = pthread_create(&threads[created], NULL, worker_main, &workers[created]);
        if (error) {
            atomic_store(&run.error, error);
            break;
        }
    }
    // Workers inherit blocked signals; only the controller handles shutdown.
    pthread_sigmask(SIG_SETMASK, &previous_mask, NULL);
    pthread_mutex_lock(&run.lock);
    while (run.ready < created)
        pthread_cond_wait(&run.condition, &run.lock);
    bool failed = atomic_load(&run.error) != 0;
    uint64_t start = monotonic_ns();
    atomic_store(&run.stop, failed || interrupted);
    run.start = true;
    pthread_cond_broadcast(&run.condition);
    pthread_mutex_unlock(&run.lock);

    uint64_t deadline_ns = start + (uint64_t)(config.duration * 1e9);
    struct timespec deadline = {.tv_sec = (time_t)(deadline_ns / UINT64_C(1000000000)),
                                .tv_nsec = (long)(deadline_ns % UINT64_C(1000000000))};
    if (!failed && !interrupted) {
        int error;
        do {
            error = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &deadline, NULL);
        } while (error == EINTR && !interrupted);
        if (error && error != EINTR)
            atomic_store(&run.error, error);
    }
    atomic_store(&run.stop, true);
    atomic_store_explicit(&run.turn, 2, memory_order_release);
    futex_wake(&run.turn, INT_MAX);
    uint64_t end = monotonic_ns();
    for (unsigned i = 0; i < created; i++)
        pthread_join(threads[i], NULL);
    int error = atomic_load(&run.error);
    if (error)
        fprintf(stderr, "Benchmark failed: %s\n", strerror(error));
    else
        print_result(&config, workers, (double)(end - start) / 1e9);
    pthread_cond_destroy(&run.condition);
    pthread_mutex_destroy(&run.lock);
    free(workers);
    free(threads);
    return error ? EXIT_FAILURE : EXIT_SUCCESS;
}
